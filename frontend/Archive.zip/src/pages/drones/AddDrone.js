"use client";

import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import {
  ArrowLeft,
  Save,
  Plus,
  X,
  Cpu,
  Zap,
  Maximize,
  Camera,
  Clock,
} from "lucide-react";
import api from "../../services/api";
import { toast } from "react-toastify";

const AddDrone = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    serialNumber: "",
    model: "",
    status: "inactive",
    capabilities: {
      maxFlightTime: 0,
      maxSpeed: 0,
      maxAltitude: 0,
      sensors: [],
    },
  });
  const [sensor, setSensor] = useState("");
  const [errors, setErrors] = useState({});

  const validateForm = () => {
    const newErrors = {};

    if (!formData.name.trim()) newErrors.name = "Drone name is required";
    if (!formData.serialNumber.trim())
      newErrors.serialNumber = "Serial number is required";
    if (!formData.model.trim()) newErrors.model = "Model is required";
    if (formData.capabilities.maxFlightTime <= 0)
      newErrors.maxFlightTime = "Flight time must be greater than 0";
    if (formData.capabilities.maxSpeed <= 0)
      newErrors.maxSpeed = "Speed must be greater than 0";
    if (formData.capabilities.maxAltitude <= 0)
      newErrors.maxAltitude = "Altitude must be greater than 0";

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;

    if (name.includes(".")) {
      const [parent, child] = name.split(".");
      setFormData({
        ...formData,
        [parent]: {
          ...formData[parent],
          [child]: value,
        },
      });
    } else {
      setFormData({
        ...formData,
        [name]: value,
      });
    }
  };

  const handleNumberChange = (e) => {
    const { name, value } = e.target;
    const [parent, child] = name.split(".");

    setFormData({
      ...formData,
      [parent]: {
        ...formData[parent],
        [child]: Number.parseFloat(value) || 0,
      },
    });
  };

  const addSensor = () => {
    if (
      sensor.trim() &&
      !formData.capabilities.sensors.includes(sensor.trim())
    ) {
      setFormData({
        ...formData,
        capabilities: {
          ...formData.capabilities,
          sensors: [...formData.capabilities.sensors, sensor.trim()],
        },
      });
      setSensor("");
    }
  };

  const removeSensor = (index) => {
    const updatedSensors = [...formData.capabilities.sensors];
    updatedSensors.splice(index, 1);

    setFormData({
      ...formData,
      capabilities: {
        ...formData.capabilities,
        sensors: updatedSensors,
      },
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validateForm()) {
      toast.error("Please fix the errors in the form");
      return;
    }

    setLoading(true);

    try {
      const response = await api.drones.create(formData);

      if (response.status === "success") {
        toast.success("Drone added successfully");
        navigate("/drones");
      } else {
        toast.error(response.message || "Failed to add drone");
      }
    } catch (error) {
      console.error("Error adding drone:", error);
      toast.error(error.message || "Failed to add drone");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <div className="flex items-center gap-2 mb-6">
        <Link to="/drones" className="btn btn-secondary btn-sm">
          <ArrowLeft size={18} />
        </Link>
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Add New Drone</h1>
          <p className="text-gray-500">Register a new drone to your fleet</p>
        </div>
      </div>

      <form onSubmit={handleSubmit}>
        <div className="bg-white rounded-lg shadow border border-gray-100 mb-6">
          <div className="p-5 border-b border-gray-100">
            <div className="flex items-center gap-2">
              <Camera className="text-primary" size={20} />
              <h2 className="text-lg font-bold">Basic Information</h2>
            </div>
          </div>

          <div className="p-5">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="form-group">
                <label
                  htmlFor="name"
                  className="block text-sm font-medium text-gray-700 mb-1"
                >
                  Drone Name*
                </label>
                <input
                  id="name"
                  name="name"
                  type="text"
                  value={formData.name}
                  onChange={handleChange}
                  placeholder="Enter drone name"
                  className={`w-full border ${
                    errors.name ? "border-red-300" : "border-gray-300"
                  } rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary focus:border-primary`}
                  required
                />
                {errors.name && (
                  <p className="mt-1 text-sm text-red-600">{errors.name}</p>
                )}
              </div>

              <div className="form-group">
                <label
                  htmlFor="serialNumber"
                  className="block text-sm font-medium text-gray-700 mb-1"
                >
                  Serial Number*
                </label>
                <input
                  id="serialNumber"
                  name="serialNumber"
                  type="text"
                  value={formData.serialNumber}
                  onChange={handleChange}
                  placeholder="Enter serial number"
                  className={`w-full border ${
                    errors.serialNumber ? "border-red-300" : "border-gray-300"
                  } rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary focus:border-primary`}
                  required
                />
                {errors.serialNumber && (
                  <p className="mt-1 text-sm text-red-600">
                    {errors.serialNumber}
                  </p>
                )}
              </div>

              <div className="form-group">
                <label
                  htmlFor="model"
                  className="block text-sm font-medium text-gray-700 mb-1"
                >
                  Model*
                </label>
                <input
                  id="model"
                  name="model"
                  type="text"
                  value={formData.model}
                  onChange={handleChange}
                  placeholder="Enter drone model"
                  className={`w-full border ${
                    errors.model ? "border-red-300" : "border-gray-300"
                  } rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary focus:border-primary`}
                  required
                />
                {errors.model && (
                  <p className="mt-1 text-sm text-red-600">{errors.model}</p>
                )}
              </div>

              <div className="form-group">
                <label
                  htmlFor="status"
                  className="block text-sm font-medium text-gray-700 mb-1"
                >
                  Status
                </label>
                <select
                  id="status"
                  name="status"
                  value={formData.status}
                  onChange={handleChange}
                  className="w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary focus:border-primary"
                  required
                >
                  <option value="active">Active</option>
                  <option value="inactive">Inactive</option>
                  <option value="maintenance">Maintenance</option>
                </select>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow border border-gray-100 mb-6">
          <div className="p-5 border-b border-gray-100">
            <div className="flex items-center gap-2">
              <Cpu className="text-primary" size={20} />
              <h2 className="text-lg font-bold">Capabilities</h2>
            </div>
          </div>

          <div className="p-5">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="form-group">
                <label
                  htmlFor="capabilities.maxFlightTime"
                  className="block text-sm font-medium text-gray-700 mb-1"
                >
                  <div className="flex items-center gap-1">
                    <Clock size={16} />
                    <span>Max Flight Time (minutes)*</span>
                  </div>
                </label>
                <input
                  id="capabilities.maxFlightTime"
                  name="capabilities.maxFlightTime"
                  type="number"
                  min="0"
                  step="0.1"
                  value={formData.capabilities.maxFlightTime}
                  onChange={handleNumberChange}
                  placeholder="Enter max flight time"
                  className={`w-full border ${
                    errors.maxFlightTime ? "border-red-300" : "border-gray-300"
                  } rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary focus:border-primary`}
                  required
                />
                {errors.maxFlightTime && (
                  <p className="mt-1 text-sm text-red-600">
                    {errors.maxFlightTime}
                  </p>
                )}
              </div>

              <div className="form-group">
                <label
                  htmlFor="capabilities.maxSpeed"
                  className="block text-sm font-medium text-gray-700 mb-1"
                >
                  <div className="flex items-center gap-1">
                    <Zap size={16} />
                    <span>Max Speed (m/s)*</span>
                  </div>
                </label>
                <input
                  id="capabilities.maxSpeed"
                  name="capabilities.maxSpeed"
                  type="number"
                  min="0"
                  step="0.1"
                  value={formData.capabilities.maxSpeed}
                  onChange={handleNumberChange}
                  placeholder="Enter max speed"
                  className={`w-full border ${
                    errors.maxSpeed ? "border-red-300" : "border-gray-300"
                  } rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary focus:border-primary`}
                  required
                />
                {errors.maxSpeed && (
                  <p className="mt-1 text-sm text-red-600">{errors.maxSpeed}</p>
                )}
              </div>

              <div className="form-group">
                <label
                  htmlFor="capabilities.maxAltitude"
                  className="block text-sm font-medium text-gray-700 mb-1"
                >
                  <div className="flex items-center gap-1">
                    <Maximize size={16} />
                    <span>Max Altitude (meters)*</span>
                  </div>
                </label>
                <input
                  id="capabilities.maxAltitude"
                  name="capabilities.maxAltitude"
                  type="number"
                  min="0"
                  step="0.1"
                  value={formData.capabilities.maxAltitude}
                  onChange={handleNumberChange}
                  placeholder="Enter max altitude"
                  className={`w-full border ${
                    errors.maxAltitude ? "border-red-300" : "border-gray-300"
                  } rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary focus:border-primary`}
                  required
                />
                {errors.maxAltitude && (
                  <p className="mt-1 text-sm text-red-600">
                    {errors.maxAltitude}
                  </p>
                )}
              </div>
            </div>

            <div className="form-group mt-6">
              <label
                htmlFor="sensor"
                className="block text-sm font-medium text-gray-700 mb-1"
              >
                <div className="flex items-center gap-1">
                  <Camera size={16} />
                  <span>Sensors</span>
                </div>
              </label>
              <div className="flex gap-2">
                <input
                  id="sensor"
                  type="text"
                  value={sensor}
                  onChange={(e) => setSensor(e.target.value)}
                  placeholder="Add a sensor (e.g., rgb, thermal)"
                  className="flex-1 border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-primary focus:border-primary"
                />
                <button
                  type="button"
                  onClick={addSensor}
                  className="inline-flex items-center px-3 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
                >
                  <Plus size={18} />
                </button>
              </div>

              <div className="flex flex-wrap gap-2 mt-3">
                {formData.capabilities.sensors.map((s, index) => (
                  <div
                    key={index}
                    className="inline-flex items-center px-2.5 py-1.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800"
                  >
                    <span>{s}</span>
                    <button
                      type="button"
                      onClick={() => removeSensor(index)}
                      className="ml-1.5 text-blue-500 hover:text-blue-700 focus:outline-none"
                    >
                      <X size={14} />
                    </button>
                  </div>
                ))}
                {formData.capabilities.sensors.length === 0 && (
                  <p className="text-sm text-gray-500">No sensors added</p>
                )}
              </div>
            </div>
          </div>
        </div>

        <div className="flex justify-end gap-2">
          <Link
            to="/drones"
            className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
          >
            Cancel
          </Link>
          <button
            type="submit"
            className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
            disabled={loading}
          >
            {loading ? (
              <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
            ) : (
              <Save size={18} className="mr-2" />
            )}
            <span>Save Drone</span>
          </button>
        </div>
      </form>
    </div>
  );
};

export default AddDrone;
