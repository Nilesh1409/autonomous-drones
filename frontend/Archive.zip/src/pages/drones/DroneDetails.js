"use client";

import { useState, useEffect } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import {
  FiArrowLeft,
  FiEdit,
  FiTrash2,
  FiBattery,
  FiMapPin,
  FiWifi,
  FiClock,
  FiActivity,
} from "react-icons/fi";
import api from "../../services/api";
import { toast } from "react-toastify";
import DroneMap from "../../components/maps/DroneMap";

/* ------------------------------------------------------------------ */

const DroneDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const [drone, setDrone] = useState(null);
  console.log("🚀 ~ DroneDetails ~ drone:", drone);
  const [missions, setMissions] = useState([]);
  const [loading, setLoading] = useState(true);

  /* ---------------- GET drone + missions -------------------------- */
  useEffect(() => {
    const load = async () => {
      try {
        /* Drone ----------------------------------------------------- */
        const d = await api.drones.getById(id);
        setDrone(d?.data?.drone);

        /* Missions that reference this drone ----------------------- */
        const allMissions = await api.missions.getAll();
        console.log("🚀 ~ load ~ allMissions:", allMissions);
        const filtered =
          allMissions?.data?.missions?.length &&
          allMissions?.data?.missions?.filter(
            (m) =>
              m.drone === id || // backend returns id
              m.droneId === id || // legacy
              m.drone?._id === id // embedded object
          );
        setMissions(filtered);
      } catch (err) {
        console.error(err);
        toast.error(err.message || "Unable to load drone");
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [id]);

  /* ---------------- Helpers -------------------------------------- */
  const badgeClass = (status) =>
    ({
      available: "badge-success",
      "in-mission": "badge-primary",
      maintenance: "badge-warning",
      inactive: "badge-gray",
    }[status] || "badge-gray");

  const deleteDrone = async () => {
    if (!window.confirm("Delete this drone?")) return;
    try {
      await api.drones.delete(id);
      toast.success("Drone deleted");
      navigate("/drones");
    } catch (err) {
      toast.error(err.message || "Delete failed");
    }
  };

  /* --------- Choose location for the map ------------------------- */
  const lastPos = drone?.telemetry?.lastKnownPosition;
  const firstMissionWithCoords = missions?.find((m) => m.location?.coordinates)
    ?.location?.coordinates;

  const mapLat = lastPos?.latitude ?? firstMissionWithCoords?.latitude ?? null;
  const mapLon =
    lastPos?.longitude ?? firstMissionWithCoords?.longitude ?? null;

  /* --------------------- Render ---------------------------------- */
  if (loading)
    return (
      <div className="flex justify-center items-center h-64">
        <div className="loading" />
      </div>
    );

  if (!drone)
    return (
      <div className="card p-8 text-center">
        <p className="text-gray mb-4">Drone not found</p>
        <Link to="/drones" className="btn btn-primary">
          Back to Drones
        </Link>
      </div>
    );

  const batt = drone?.telemetry?.batteryLevel ?? 0;

  return (
    <div>
      {/* ---------- Header ----------------------------------------- */}
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center gap-2">
          <Link to="/drones" className="btn btn-secondary btn-sm">
            <FiArrowLeft />
          </Link>
          <h1 className="text-2xl font-bold">{drone.name}</h1>
          <span className={`badge ${badgeClass(drone.status)}`}>
            {drone.status}
          </span>
        </div>

        <div className="flex gap-2">
          <Link
            to={`/drones/edit/${id}`}
            className="btn btn-secondary flex items-center gap-2"
          >
            <FiEdit />
            <span>Edit</span>
          </Link>
          <button
            onClick={deleteDrone}
            className="btn btn-danger flex items-center gap-2"
          >
            <FiTrash2 />
            <span>Delete</span>
          </button>
        </div>
      </div>

      {/* ---------- Grid ------------------------------------------- */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* === LEFT column ========================================= */}
        <div className="lg:col-span-1">
          {/* Info card */}
          <Card title="Drone Information">
            <Info label="Model" value={drone.model} />
            <Info label="Serial" value={drone.serialNumber} />
            <Info label="Status" value={drone.status} />
            <Info
              label="Created"
              value={new Date(drone.createdAt).toLocaleString()}
            />
            <Info
              label="Updated"
              value={new Date(drone.updatedAt).toLocaleString()}
            />
          </Card>

          {/* Capabilities */}
          <Card title="Capabilities">
            <Info
              label="Max Flight Time"
              value={`${drone.capabilities?.maxFlightTime ?? "—"} min`}
            />
            <Info
              label="Max Speed"
              value={`${drone.capabilities?.maxSpeed ?? "—"} m/s`}
            />
            <Info
              label="Max Altitude"
              value={`${drone.capabilities?.maxAltitude ?? "—"} m`}
            />
            <Info
              label="Sensors"
              value={
                drone.capabilities?.sensors?.length
                  ? drone.capabilities.sensors.join(", ")
                  : "—"
              }
            />
          </Card>

          {/* Maintenance */}
          <Card title="Maintenance">
            <Info
              label="Flight Hours"
              value={`${drone.maintenanceInfo?.flightHours ?? 0} h`}
            />
          </Card>

          {/* Telemetry */}
          <Card title="Telemetry">
            {lastPos || batt ? (
              <>
                <Stat
                  icon={FiBattery}
                  label="Battery"
                  value={`${batt}%`}
                  progress={batt}
                />
                <Stat
                  icon={FiMapPin}
                  label="Location"
                  value={
                    lastPos
                      ? `${lastPos.latitude.toFixed(
                          6
                        )}, ${lastPos.longitude.toFixed(6)}`
                      : "—"
                  }
                />
                <Stat
                  icon={FiClock}
                  label="Last Updated"
                  value={
                    drone?.telemetry?.lastUpdated
                      ? new Date(
                          drone.telemetry.lastUpdated
                        ).toLocaleTimeString()
                      : "—"
                  }
                />
                <Stat icon={FiWifi} label="Signal Strength" value="Good" />
              </>
            ) : (
              <p className="text-gray">No telemetry data</p>
            )}
          </Card>
        </div>

        {/* === RIGHT column (Map & Missions) ======================= */}
        <div className="lg:col-span-2">
          {/* Map */}
          <Card title="Location" className="h-80 mb-6">
            {mapLat && mapLon ? (
              <DroneMap drone={drone} latitude={mapLat} longitude={mapLon} />
            ) : (
              <CenterPlaceholder>No location data</CenterPlaceholder>
            )}
          </Card>

          {/* Missions */}
          <Card title="Recent Missions">
            {missions?.length === 0 ? (
              <CenterPlaceholder>No missions for this drone</CenterPlaceholder>
            ) : (
              <div className="overflow-x-auto">
                <table className="table">
                  <thead>
                    <tr>
                      <th>Name</th>
                      <th>Type</th>
                      <th>Status</th>
                      <th>Date</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {missions?.length &&
                      missions.map((m) => (
                        <tr key={m._id}>
                          <td>{m.name}</td>
                          <td>{m.missionType}</td>
                          <td>
                            <span className={`badge ${missionBadge(m.status)}`}>
                              {m.status}
                            </span>
                          </td>
                          <td>
                            {m.createdAt
                              ? new Date(m.createdAt).toLocaleDateString()
                              : "—"}
                          </td>
                          <td>
                            <Link
                              to={`/missions/${m._id}`}
                              className="btn btn-secondary btn-sm"
                            >
                              View
                            </Link>
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
};

/* ---------------- Small reusable pieces ----------------------------- */

const Card = ({ title, children, className = "" }) => (
  <div className={`card ${className}`}>
    <h2 className="text-lg font-bold mb-4">{title}</h2>
    {children}
  </div>
);

const Info = ({ label, value }) => (
  <div className="mb-2">
    <p className="text-sm text-gray">{label}</p>
    <p className="font-medium break-all">{value}</p>
  </div>
);

const Stat = ({ icon: Icon, label, value, progress }) => (
  <div className="flex items-center gap-3 mb-3">
    <div className="p-2 bg-light rounded-lg">
      <Icon className="text-primary" size={20} />
    </div>
    <div className="flex-1">
      <p className="text-sm text-gray">{label}</p>
      {typeof progress === "number" ? (
        <>
          <div className="w-full bg-gray-light rounded-full h-2.5 mt-1">
            <div
              className="bg-primary h-2.5 rounded-full"
              style={{ width: `${progress}%` }}
            />
          </div>
          <p className="text-sm font-medium mt-1">{value}</p>
        </>
      ) : (
        <p className="font-medium">{value}</p>
      )}
    </div>
  </div>
);

const CenterPlaceholder = ({ children }) => (
  <div className="flex justify-center items-center h-full bg-light rounded-lg">
    <p className="text-gray">{children}</p>
  </div>
);

const missionBadge = (s) =>
  ({
    completed: "badge-success",
    "in-progress": "badge-primary",
    planned: "badge-gray",
    aborted: "badge-danger",
    paused: "badge-warning",
  }[s] || "badge-gray");

/* ------------------------------------------------------------------ */

export default DroneDetails;
