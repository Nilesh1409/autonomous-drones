"use client";

import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import {
  PlusCircle,
  Search,
  Filter,
  RefreshCw,
  Trash2,
  Battery,
  Wifi,
  AlertTriangle,
  CheckCircle,
  Clock,
  Eye,
  Camera,
} from "lucide-react";
import api from "../../services/api";
import { toast } from "react-toastify";

const DronesList = () => {
  const [drones, setDrones] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [error, setError] = useState(null);

  const fetchDrones = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await api.drones.getAll();

      if (response.status === "success") {
        setDrones(response.data.drones);
      } else {
        setError("Failed to fetch drones");
        toast.error("Failed to fetch drones");
      }
    } catch (error) {
      console.error("Error fetching drones:", error);
      setError("Failed to fetch drones. Please try again.");
      toast.error(error.message || "Failed to fetch drones");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDrones();
  }, []);

  const handleDelete = async (id) => {
    if (window.confirm("Are you sure you want to delete this drone?")) {
      try {
        const response = await api.drones.delete(id);

        if (response.status === "success" || response.status === 204) {
          setDrones(drones.filter((drone) => drone._id !== id));
          toast.success("Drone deleted successfully");
        } else {
          toast.error("Failed to delete drone");
        }
      } catch (error) {
        console.error("Error deleting drone:", error);
        toast.error(error.message || "Failed to delete drone");
      }
    }
  };

  const filteredDrones = drones?.filter((drone) => {
    const matchesSearch =
      drone.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      drone.model.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (drone.serialNumber &&
        drone.serialNumber.toLowerCase().includes(searchTerm.toLowerCase()));

    const matchesStatus =
      statusFilter === "all" || drone.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  const getStatusBadge = (status) => {
    switch (status) {
      case "active":
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
            <CheckCircle size={12} className="mr-1" />
            Active
          </span>
        );
      case "maintenance":
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
            <AlertTriangle size={12} className="mr-1" />
            Maintenance
          </span>
        );
      case "inactive":
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
            <Clock size={12} className="mr-1" />
            Inactive
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
            {status}
          </span>
        );
    }
  };

  const getBatteryIndicator = (level) => {
    if (!level && level !== 0) return null;

    let color = "text-green-500";
    if (level < 30) color = "text-red-500";
    else if (level < 70) color = "text-yellow-500";

    return (
      <div className="flex items-center">
        <Battery className={color} size={16} />
        <span className="ml-1 text-sm">{level}%</span>
      </div>
    );
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="loading"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">
        <p>{error}</p>
        <button
          onClick={fetchDrones}
          className="mt-2 text-sm font-medium text-red-700 hover:text-red-900"
        >
          Retry
        </button>
      </div>
    );
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Drone Fleet</h1>
          <p className="text-gray-500">Manage your drone inventory</p>
        </div>
        <Link
          to="/drones/add"
          className="btn btn-primary flex items-center gap-2"
        >
          <PlusCircle size={18} />
          <span>Add Drone</span>
        </Link>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-lg shadow border border-gray-100 p-5 mb-6">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400">
              <Search size={18} />
            </span>
            <input
              type="text"
              placeholder="Search drones by name, model, or serial number..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 w-full border border-gray-200 rounded-lg py-2 px-3 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
            />
          </div>

          <div className="md:w-48">
            <div className="relative">
              <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400">
                <Filter size={18} />
              </span>
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="pl-10 w-full border border-gray-200 rounded-lg py-2 px-3 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent appearance-none"
              >
                <option value="all">All Status</option>
                <option value="active">Active</option>
                <option value="maintenance">Maintenance</option>
                <option value="inactive">Inactive</option>
              </select>
            </div>
          </div>

          <button
            className="btn btn-secondary flex items-center gap-2 md:w-auto"
            onClick={fetchDrones}
          >
            <RefreshCw size={18} />
            <span>Refresh</span>
          </button>
        </div>
      </div>

      {/* Drones List */}
      {filteredDrones.length === 0 ? (
        <div className="bg-white rounded-lg shadow border border-gray-100 p-8 text-center">
          <div className="flex flex-col items-center justify-center">
            <Camera size={48} className="text-gray-300 mb-4" />
            <p className="text-gray-500 mb-4">No drones found</p>
            <Link to="/drones/add" className="btn btn-primary">
              Add Drone
            </Link>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredDrones.map((drone) => (
            <div
              key={drone._id}
              className="bg-white rounded-lg shadow border border-gray-100 hover:shadow-md transition-shadow duration-200"
            >
              <div className="p-5 border-b border-gray-100">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="text-lg font-bold text-gray-900">
                    {drone.name}
                  </h3>
                  {getStatusBadge(drone.status)}
                </div>
                <div className="text-sm text-gray-500 mb-2">
                  <p>Model: {drone.model}</p>
                  <p>Serial: {drone.serialNumber || "N/A"}</p>
                </div>
                <div className="flex items-center gap-4 mt-3">
                  {getBatteryIndicator(drone.telemetry?.batteryLevel)}
                  {drone.status === "active" && (
                    <div className="flex items-center text-blue-500">
                      <Wifi size={16} />
                      <span className="ml-1 text-sm">Connected</span>
                    </div>
                  )}
                </div>
              </div>

              <div className="p-5">
                <div className="flex flex-wrap gap-2 mb-4">
                  {drone.capabilities?.sensors?.map((sensor, index) => (
                    <span
                      key={index}
                      className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800"
                    >
                      {sensor}
                    </span>
                  ))}
                  {(!drone.capabilities?.sensors ||
                    drone.capabilities.sensors.length === 0) && (
                    <span className="text-sm text-gray-400">
                      No sensors specified
                    </span>
                  )}
                </div>

                <div className="flex justify-between">
                  <Link
                    to={`/drones/${drone._id}`}
                    className="flex-1 mr-2 inline-flex justify-center items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
                  >
                    <Eye size={16} className="mr-2" />
                    View Details
                  </Link>

                  <button
                    onClick={() => handleDelete(drone._id)}
                    className="inline-flex items-center px-3 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default DronesList;
