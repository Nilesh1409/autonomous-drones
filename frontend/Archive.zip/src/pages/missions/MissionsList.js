"use client";

import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import {
  PlusCircle,
  Search,
  Filter,
  RefreshCw,
  Eye,
  Play,
  Pause,
  Check,
  X,
  Map,
  Calendar,
  MapPin,
  Clock,
} from "lucide-react";
import api from "../../services/api";
import { toast } from "react-toastify";

const MissionsList = () => {
  const [missions, setMissions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [typeFilter, setTypeFilter] = useState("all");
  const [error, setError] = useState(null);

  const fetchMissions = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await api.missions.getAll();

      if (response.status === "success") {
        setMissions(response.data.missions);
      } else {
        setError("Failed to fetch missions");
        toast.error("Failed to fetch missions");
      }
    } catch (error) {
      console.error("Error fetching missions:", error);
      setError("Failed to fetch missions. Please try again.");
      toast.error(error.message || "Failed to fetch missions");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMissions();
  }, []);

  const handleMissionAction = async (id, action) => {
    try {
      let response;

      switch (action) {
        case "start":
          response = await api.missions.start(id);
          break;
        case "pause":
          response = await api.missions.pause(id);
          break;
        case "resume":
          response = await api.missions.resume(id);
          break;
        case "complete":
          response = await api.missions.complete(id);
          break;
        case "abort":
          response = await api.missions.abort(id);
          break;
        default:
          throw new Error("Invalid action");
      }

      if (response.status === "success") {
        // Update mission status in the UI
        setMissions(
          missions.map((mission) => {
            if (mission._id === id) {
              let newStatus;
              switch (action) {
                case "start":
                  newStatus = "in-progress";
                  break;
                case "pause":
                  newStatus = "paused";
                  break;
                case "resume":
                  newStatus = "in-progress";
                  break;
                case "complete":
                  newStatus = "completed";
                  break;
                case "abort":
                  newStatus = "aborted";
                  break;
                default:
                  newStatus = mission.status;
              }

              return { ...mission, status: newStatus };
            }
            return mission;
          })
        );

        toast.success(`Mission ${action}ed successfully`);
      } else {
        toast.error(`Failed to ${action} mission`);
      }
    } catch (error) {
      console.error(`Error ${action}ing mission:`, error);
      toast.error(error.message || `Failed to ${action} mission`);
    }
  };

  const filteredMissions = missions.filter((mission) => {
    const matchesSearch =
      mission.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (mission.description &&
        mission.description.toLowerCase().includes(searchTerm.toLowerCase()));

    const matchesStatus =
      statusFilter === "all" || mission.status === statusFilter;
    const matchesType =
      typeFilter === "all" || mission.missionType === typeFilter;

    return matchesSearch && matchesStatus && matchesType;
  });

  const getStatusBadge = (status) => {
    switch (status) {
      case "completed":
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
            <Check size={12} className="mr-1" />
            Completed
          </span>
        );
      case "in-progress":
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
            <Play size={12} className="mr-1" />
            In Progress
          </span>
        );
      case "paused":
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
            <Pause size={12} className="mr-1" />
            Paused
          </span>
        );
      case "scheduled":
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
            <Calendar size={12} className="mr-1" />
            Scheduled
          </span>
        );
      case "aborted":
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
            <X size={12} className="mr-1" />
            Aborted
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
            {status}
          </span>
        );
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="loading"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">
        <p>{error}</p>
        <button
          onClick={fetchMissions}
          className="mt-2 text-sm font-medium text-red-700 hover:text-red-900"
        >
          Retry
        </button>
      </div>
    );
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Missions</h1>
          <p className="text-gray-500">
            Plan and manage your drone survey missions
          </p>
        </div>
        <Link
          to="/missions/plan"
          className="btn btn-primary flex items-center gap-2"
        >
          <PlusCircle size={18} />
          <span>Plan Mission</span>
        </Link>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-lg shadow border border-gray-100 p-5 mb-6">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400">
              <Search size={18} />
            </span>
            <input
              type="text"
              placeholder="Search missions..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 w-full border border-gray-200 rounded-lg py-2 px-3 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
            />
          </div>

          <div className="md:w-48">
            <div className="relative">
              <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400">
                <Filter size={18} />
              </span>
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="pl-10 w-full border border-gray-200 rounded-lg py-2 px-3 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent appearance-none"
              >
                <option value="all">All Status</option>
                <option value="scheduled">Scheduled</option>
                <option value="in-progress">In Progress</option>
                <option value="paused">Paused</option>
                <option value="completed">Completed</option>
                <option value="aborted">Aborted</option>
              </select>
            </div>
          </div>

          <div className="md:w-48">
            <div className="relative">
              <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400">
                <Filter size={18} />
              </span>
              <select
                value={typeFilter}
                onChange={(e) => setTypeFilter(e.target.value)}
                className="pl-10 w-full border border-gray-200 rounded-lg py-2 px-3 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent appearance-none"
              >
                <option value="all">All Types</option>
                <option value="mapping">Mapping</option>
                <option value="inspection">Inspection</option>
                <option value="surveillance">Surveillance</option>
                <option value="survey">Survey</option>
              </select>
            </div>
          </div>

          <button
            className="btn btn-secondary flex items-center gap-2 md:w-auto"
            onClick={fetchMissions}
          >
            <RefreshCw size={18} />
            <span>Refresh</span>
          </button>
        </div>
      </div>

      {/* Missions List */}
      {filteredMissions.length === 0 ? (
        <div className="bg-white rounded-lg shadow border border-gray-100 p-8 text-center">
          <div className="flex flex-col items-center justify-center">
            <Map size={48} className="text-gray-300 mb-4" />
            <p className="text-gray-500 mb-4">No missions found</p>
            <Link to="/missions/plan" className="btn btn-primary">
              Plan Mission
            </Link>
          </div>
        </div>
      ) : (
        <div className="bg-white rounded-lg shadow border border-gray-100 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    Mission Name
                  </th>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    Type
                  </th>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    Location
                  </th>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    Status
                  </th>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    Progress
                  </th>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    Schedule
                  </th>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredMissions.map((mission) => (
                  <tr key={mission._id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="font-medium text-gray-900">
                        {mission.name}
                      </div>
                      <div className="text-sm text-gray-500">
                        {mission.description
                          ? mission.description.length > 50
                            ? `${mission.description.substring(0, 50)}...`
                            : mission.description
                          : "No description"}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900 capitalize">
                        {mission.missionType}
                      </div>
                      <div className="text-sm text-gray-500 capitalize">
                        {mission.patternType}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <MapPin size={16} className="text-gray-400 mr-1" />
                        <span className="text-sm text-gray-900">
                          {mission.location?.name || "N/A"}
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {getStatusBadge(mission.status)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="w-full bg-gray-200 rounded-full h-2.5">
                        <div
                          className="bg-primary h-2.5 rounded-full"
                          style={{ width: `${mission.percentComplete || 0}%` }}
                        ></div>
                      </div>
                      <div className="text-xs text-gray-500 mt-1">
                        {mission.percentComplete || 0}%
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {mission.schedule?.startTime ? (
                        <div>
                          <div className="flex items-center text-sm text-gray-900">
                            <Calendar
                              size={14}
                              className="text-gray-400 mr-1"
                            />
                            {new Date(
                              mission.schedule.startTime
                            ).toLocaleDateString()}
                          </div>
                          <div className="flex items-center text-xs text-gray-500">
                            <Clock size={12} className="mr-1" />
                            {new Date(
                              mission.schedule.startTime
                            ).toLocaleTimeString([], {
                              hour: "2-digit",
                              minute: "2-digit",
                            })}
                          </div>
                        </div>
                      ) : (
                        <span className="text-sm text-gray-500">
                          Not scheduled
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <div className="flex gap-1">
                        <Link
                          to={`/missions/${mission._id}`}
                          className="text-primary hover:text-primary-dark p-1 rounded-full hover:bg-gray-100"
                          title="View Details"
                        >
                          <Eye size={18} />
                        </Link>

                        {mission.status === "scheduled" && (
                          <button
                            onClick={() =>
                              handleMissionAction(mission._id, "start")
                            }
                            className="text-blue-600 hover:text-blue-800 p-1 rounded-full hover:bg-blue-50"
                            title="Start Mission"
                          >
                            <Play size={18} />
                          </button>
                        )}

                        {mission.status === "in-progress" && (
                          <>
                            <button
                              onClick={() =>
                                handleMissionAction(mission._id, "pause")
                              }
                              className="text-yellow-600 hover:text-yellow-800 p-1 rounded-full hover:bg-yellow-50"
                              title="Pause Mission"
                            >
                              <Pause size={18} />
                            </button>

                            <button
                              onClick={() =>
                                handleMissionAction(mission._id, "complete")
                              }
                              className="text-green-600 hover:text-green-800 p-1 rounded-full hover:bg-green-50"
                              title="Complete Mission"
                            >
                              <Check size={18} />
                            </button>
                          </>
                        )}

                        {mission.status === "paused" && (
                          <button
                            onClick={() =>
                              handleMissionAction(mission._id, "resume")
                            }
                            className="text-blue-600 hover:text-blue-800 p-1 rounded-full hover:bg-blue-50"
                            title="Resume Mission"
                          >
                            <Play size={18} />
                          </button>
                        )}

                        {(mission.status === "in-progress" ||
                          mission.status === "paused") && (
                          <button
                            onClick={() =>
                              handleMissionAction(mission._id, "abort")
                            }
                            className="text-red-600 hover:text-red-800 p-1 rounded-full hover:bg-red-50"
                            title="Abort Mission"
                          >
                            <X size={18} />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

export default MissionsList;
