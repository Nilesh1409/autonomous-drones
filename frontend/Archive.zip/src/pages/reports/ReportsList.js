"use client";

import { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import {
  FiArrowLeft,
  FiDownload,
  FiEdit,
  FiMapPin,
  FiThermometer,
  FiWind,
  FiDroplet,
  FiPlus,
} from "react-icons/fi";
import api from "../../services/api";
import { toast } from "react-toastify";

const ReportDetails = () => {
  const { id } = useParams();

  const [report, setReport] = useState(null);
  const [mission, setMission] = useState(null);
  const [loading, setLoading] = useState(true);

  /* ---------- fetch report + optional mission --------------- */
  useEffect(() => {
    const load = async () => {
      try {
        const rep = await api.reports.getAll();
        console.log("🚀 ~ load ~ rep:", rep);
        setReport(rep?.data?.reports);

        const missionRef =
          rep.mission?._id || rep.mission || rep.missionId || null;

        if (missionRef) {
          const mis = await api.missions.getAll();
          console.log("🚀 ~ load ~ mis:", mis);
          setMission(mis?.data?.missions);
        }
      } catch (err) {
        console.error(err);
        toast.error(err.message || "Failed to fetch report");
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [id]);

  const badge =
    report?.status === "published"
      ? "badge-success"
      : report?.status === "draft"
      ? "badge-warning"
      : "badge-gray";

  const priorityBadge = (p) =>
    p === "high"
      ? "badge-danger"
      : p === "medium"
      ? "badge-warning"
      : p === "low"
      ? "badge-success"
      : "badge-gray";

  /* ---------- loading / not found --------------------------- */
  if (loading)
    return (
      <div className="flex justify-center items-center h-64">
        <div className="loading" />
      </div>
    );

  if (!report)
    return (
      <div className="card p-8 text-center">
        <p className="text-gray mb-4">Report not found</p>
        <Link to="/reports" className="btn btn-primary">
          Back to Reports
        </Link>
      </div>
    );

  /* ---------- render ---------------------------------------- */
  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Reports</h1>
      </div>
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center gap-2">
          <Link to="/reports" className="btn btn-secondary btn-sm">
            <FiArrowLeft />
          </Link>
          <h1 className="text-2xl font-bold">{report.title}</h1>
          <span className={`badge ${badge}`}>{report.status}</span>
        </div>

        <div className="flex gap-2">
          <Link
            to="/reports/create"
            className="btn btn-primary flex items-center gap-2"
          >
            <FiPlus />
            <span>Create Report</span>
          </Link>
          <Link
            to={`/reports/edit/${id}`}
            className="btn btn-secondary flex items-center gap-2"
          >
            <FiEdit />
            <span>Edit</span>
          </Link>
          <button className="btn btn-primary flex items-center gap-2">
            <FiDownload />
            <span>Download</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* main column -------------------------------------------------- */}
        <div className="lg:col-span-2">
          <Card title="Summary">
            <p className="text-gray">{report.summary || "—"}</p>
          </Card>

          <Card title="Findings">
            {Array.isArray(report.findings) && report.findings.length ? (
              <div className="space-y-4">
                {report.findings.map((f, i) => (
                  <div key={i} className="p-4 bg-light rounded-lg">
                    <div className="flex justify-between mb-2">
                      <h3 className="font-bold">{f.category}</h3>
                      <span className={`badge ${priorityBadge(f.priority)}`}>
                        {f.priority}
                      </span>
                    </div>
                    <p className="mb-2">{f.description}</p>
                    {f.location && (
                      <div className="flex items-center gap-2 text-xs text-gray">
                        <FiMapPin />
                        <span>
                          {f.location.latitude.toFixed(6)},{" "}
                          {f.location.longitude.toFixed(6)}
                        </span>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gray">No findings reported</p>
            )}
          </Card>

          <Card title="Issues">
            {Array.isArray(report.issues) && report.issues.length ? (
              <div className="space-y-4">
                {report.issues.map((iss, i) => (
                  <div key={i} className="p-4 bg-light rounded-lg">
                    <div className="flex justify-between mb-2">
                      <h3 className="font-bold capitalize">{iss.type}</h3>
                      <span className={`badge ${priorityBadge(iss.severity)}`}>
                        {iss.severity}
                      </span>
                    </div>
                    <p>{iss.description}</p>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gray">No issues reported</p>
            )}
          </Card>
        </div>

        {/* sidebar ------------------------------------------------------ */}
        <div className="lg:col-span-1">
          {mission && (
            <Card title="Mission Information">
              <Info label="Mission Name" value={mission.name} />
              <Info label="Mission Type" value={mission.missionType} />
              <Info label="Location" value={mission.location?.name || "N/A"} />
              <Info
                label="Date"
                value={
                  mission.schedule?.startTime
                    ? new Date(mission.schedule.startTime).toLocaleDateString()
                    : "Not specified"
                }
              />
              <Link
                to={`/missions/${mission._id}`}
                className="btn btn-secondary btn-sm w-full text-center mt-3"
              >
                View Mission
              </Link>
            </Card>
          )}

          <Card title="Flight Statistics">
            {report.flightStatistics ? (
              <TwoColStats
                stats={[
                  ["Duration", `${report.flightStatistics.duration} min`],
                  ["Distance", `${report.flightStatistics.distance} km`],
                  ["Max Altitude", `${report.flightStatistics.maxAltitude} m`],
                  ["Max Speed", `${report.flightStatistics.maxSpeed} m/s`],
                  ["Area Covered", `${report.flightStatistics.areaCovered} m²`],
                  ["Battery Used", `${report.flightStatistics.batteryUsed}%`],
                ]}
              />
            ) : (
              <p className="text-gray">No flight statistics available</p>
            )}
          </Card>

          <Card title="Weather Conditions">
            {report.weatherConditions ? (
              <div className="space-y-4">
                <Weather
                  icon={FiThermometer}
                  label="Temperature"
                  value={`${report.weatherConditions.temperature} °C`}
                />
                <Weather
                  icon={FiWind}
                  label="Wind Speed"
                  value={`${report.weatherConditions.windSpeed} m/s`}
                />
                <Weather
                  icon={FiDroplet}
                  label="Humidity"
                  value={`${report.weatherConditions.humidity}%`}
                />
                <Info
                  label="Conditions"
                  value={report.weatherConditions.conditions}
                />
              </div>
            ) : (
              <p className="text-gray">No weather data available</p>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
};

/* ---------- small helpers ---------------------------------- */
const Card = ({ title, children }) => (
  <div className="card mb-6">
    <h2 className="text-lg font-bold mb-4">{title}</h2>
    {children}
  </div>
);

const Info = ({ label, value }) => (
  <div className="mb-2">
    <p className="text-sm text-gray">{label}</p>
    <p className="font-medium break-all">{value}</p>
  </div>
);

const TwoColStats = ({ stats }) => (
  <div className="grid grid-cols-2 gap-4">
    {stats.map(([k, v]) => (
      <div key={k}>
        <p className="text-sm text-gray">{k}</p>
        <p className="font-medium">{v}</p>
      </div>
    ))}
  </div>
);

const Weather = ({ icon: Icon, label, value }) => (
  <div className="flex items-center gap-3">
    <div className="p-2 bg-light rounded-lg">
      <Icon className="text-primary" size={20} />
    </div>
    <div>
      <p className="text-sm text-gray">{label}</p>
      <p className="font-medium">{value}</p>
    </div>
  </div>
);

export default ReportDetails;
