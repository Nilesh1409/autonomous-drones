"use client";

import { useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import {
  FiMail,
  FiLock,
  FiUser,
  FiBriefcase,
  FiFileText,
  FiUserPlus,
} from "react-icons/fi";

const Register = () => {
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    name: "",
    organizationName: "",
    organizationDescription: "",
  });
  const [loading, setLoading] = useState(false);
  const { register } = useAuth();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      await register(formData);
    } catch (error) {
      // Error is already handled in the AuthContext
      console.error("Registration error:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <h2 className="text-2xl font-bold mb-6 text-center">Register</h2>

      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="email">Email</label>
          <div className="relative">
            <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray">
              <FiMail />
            </span>
            <input
              id="email"
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              placeholder="Enter your email"
              required
              className="pl-10"
            />
          </div>
        </div>

        <div className="form-group">
          <label htmlFor="password">Password</label>
          <div className="relative">
            <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray">
              <FiLock />
            </span>
            <input
              id="password"
              type="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              placeholder="Enter your password"
              required
              className="pl-10"
            />
          </div>
        </div>

        <div className="form-group">
          <label htmlFor="name">Your Name</label>
          <div className="relative">
            <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray">
              <FiUser />
            </span>
            <input
              id="name"
              type="text"
              name="name"
              value={formData.name}
              onChange={handleChange}
              placeholder="Enter your name"
              required
              className="pl-10"
            />
          </div>
        </div>

        <div className="form-group">
          <label htmlFor="organizationName">Organization Name</label>
          <div className="relative">
            <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray">
              <FiBriefcase />
            </span>
            <input
              id="organizationName"
              type="text"
              name="organizationName"
              value={formData.organizationName}
              onChange={handleChange}
              placeholder="Enter organization name"
              required
              className="pl-10"
            />
          </div>
        </div>

        <div className="form-group">
          <label htmlFor="organizationDescription">
            Organization Description
          </label>
          <div className="relative">
            <span className="absolute left-3 top-3 text-gray">
              <FiFileText />
            </span>
            <textarea
              id="organizationDescription"
              name="organizationDescription"
              value={formData.organizationDescription}
              onChange={handleChange}
              placeholder="Enter organization description"
              rows="3"
              className="pl-10"
            ></textarea>
          </div>
        </div>

        <button
          type="submit"
          className="btn btn-primary w-full flex items-center justify-center gap-2 mt-4"
          disabled={loading}
        >
          {loading ? (
            <div className="loading"></div>
          ) : (
            <>
              <FiUserPlus />
              <span>Register</span>
            </>
          )}
        </button>
      </form>

      <div className="mt-4 text-center">
        <p>
          Already have an account?{" "}
          <Link to="/login" className="text-primary">
            Login
          </Link>
        </p>
      </div>
    </div>
  );
};

export default Register;
