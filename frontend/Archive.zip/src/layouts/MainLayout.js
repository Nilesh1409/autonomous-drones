"use client";

import { useState } from "react";
import { Outlet, NavLink, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import {
  Home,
  Clipboard,
  Map,
  FileText,
  User,
  LogOut,
  Menu,
  X,
  Bell,
} from "lucide-react";

const MainLayout = () => {
  const { currentUser, logout } = useAuth();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  return (
    <div className="flex h-screen bg-light">
      {/* Sidebar */}
      <aside
        className={`bg-white shadow-lg fixed inset-y-0 left-0 z-10 w-64 transform transition-transform duration-300 ease-in-out ${
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        } md:relative md:translate-x-0`}
      >
        <div className="flex items-center justify-between h-16 px-4 border-b">
          <h1 className="text-xl font-bold text-primary">Drone Survey</h1>
          <button className="md:hidden text-gray" onClick={toggleSidebar}>
            <X size={24} />
          </button>
        </div>

        <nav className="mt-6 px-4">
          <NavLink
            to="/"
            className={({ isActive }) =>
              `flex items-center gap-2 p-3 rounded-lg mb-2 ${
                isActive ? "bg-primary text-white" : "hover:bg-light"
              }`
            }
            onClick={() => setSidebarOpen(false)}
          >
            <Home size={20} />
            <span>Dashboard</span>
          </NavLink>

          <NavLink
            to="/drones"
            className={({ isActive }) =>
              `flex items-center gap-2 p-3 rounded-lg mb-2 ${
                isActive ? "bg-primary text-white" : "hover:bg-light"
              }`
            }
            onClick={() => setSidebarOpen(false)}
          >
            <Clipboard size={20} />
            <span>Drones</span>
          </NavLink>

          <NavLink
            to="/missions"
            className={({ isActive }) =>
              `flex items-center gap-2 p-3 rounded-lg mb-2 ${
                isActive ? "bg-primary text-white" : "hover:bg-light"
              }`
            }
            onClick={() => setSidebarOpen(false)}
          >
            <Map size={20} />
            <span>Missions</span>
          </NavLink>

          <NavLink
            to="/reports"
            className={({ isActive }) =>
              `flex items-center gap-2 p-3 rounded-lg mb-2 ${
                isActive ? "bg-primary text-white" : "hover:bg-light"
              }`
            }
            onClick={() => setSidebarOpen(false)}
          >
            <FileText size={20} />
            <span>Reports</span>
          </NavLink>

          <NavLink
            to="/profile"
            className={({ isActive }) =>
              `flex items-center gap-2 p-3 rounded-lg mb-2 ${
                isActive ? "bg-primary text-white" : "hover:bg-light"
              }`
            }
            onClick={() => setSidebarOpen(false)}
          >
            <User size={20} />
            <span>Profile</span>
          </NavLink>

          <button
            onClick={handleLogout}
            className="flex items-center gap-2 p-3 rounded-lg mb-2 w-full text-left hover:bg-light text-danger"
          >
            <LogOut size={20} />
            <span>Logout</span>
          </button>
        </nav>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="bg-white shadow-sm h-16 flex items-center justify-between px-4">
          <button className="md:hidden text-gray" onClick={toggleSidebar}>
            <Menu size={24} />
          </button>

          <div className="flex items-center gap-4">
            <div className="relative">
              <Bell size={20} className="text-gray" />
              <span className="absolute -top-1 -right-1 bg-danger text-white rounded-full w-4 h-4 flex items-center justify-center text-xs">
                3
              </span>
            </div>

            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-primary text-white rounded-full flex items-center justify-center">
                {currentUser?.name?.charAt(0) || "U"}
              </div>
              <span className="hidden md:block">
                {currentUser?.name || "User"}
              </span>
            </div>
          </div>
        </header>

        {/* Content */}
        <main className="flex-1 overflow-y-auto p-4">
          <Outlet />
        </main>
      </div>

      {/* Overlay for mobile sidebar */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-0 md:hidden"
          onClick={toggleSidebar}
        ></div>
      )}
    </div>
  );
};

export default MainLayout;
